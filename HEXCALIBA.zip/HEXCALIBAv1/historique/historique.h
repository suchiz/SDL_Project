#ifndef HISTORIQUE
#define HISTORIQUE



#include "../global.h"
#include "../fonctions.h"

void default_historique (SDL_Surface *ecran, int i);
void button_historique (int *menu, int clicX, int clicY);
void hover_historique (SDL_Surface *ecran, SDL_Event event);

#endif