#ifndef SAUVEGARDER
#define SAUVEGARDER

#include <time.h>
#include <string.h>

void save(int i);

#endif